package uk.co.caprica.vlcjplayer;

public enum VideoOutput {

    EMBEDDED,
    CALLBACK

}
